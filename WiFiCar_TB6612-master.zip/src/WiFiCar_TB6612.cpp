/******************************************************************************
WiFiCar_TB6612.cpp
TB6612FNG Motor Driver code
Nicky @ linkbay.co.kr
2021/03/01
https://github.com/copaland/WiFiCar_TB6612

Uses 2 motors to show examples of the functions in the library. 
Each movement has an equal and opposite movement
so assuming your motors are balanced the bot should end up at the same place it
started.

Resources:
TB6612 WiFiCar Library

Development environment specifics:
Developed on Arduino 1.8.13
Developed with K-2101
******************************************************************************/

#include "WiFiCar_TB6612.h"
#include <Arduino.h>

Motor::Motor(int INpin, int PWMpin, int DIRset)
{
  In1 = INpin;
  PWM = PWMpin;
  DIR = DIRset;
  
  pinMode(In1, OUTPUT);
  pinMode(PWM, OUTPUT);
}

void Motor::drive(int speed)
{
  speed = speed * DIR;
  if (speed>=0) fwd(speed);
  else rev(-speed);
}

void Motor::drive(int speed, int duration)
{
  drive(speed);
  delay(duration);
}

void Motor::fwd(int speed)
{
   digitalWrite(In1, HIGH);
   analogWrite(PWM, speed);
}

void Motor::rev(int speed)
{
   digitalWrite(In1, LOW);
   analogWrite(PWM, speed);
}

void Motor::brake()
{
   digitalWrite(In1, HIGH);
   analogWrite(PWM,0);
}

void forward(Motor M1, Motor M2, int speed)
{
	M1.drive(speed);
	M2.drive(speed);
}

void forward(Motor M1, Motor M2)
{
	M1.drive(DEFAULTSPEED);
	M2.drive(DEFAULTSPEED);
}


void backward(Motor M1, Motor M2, int speed)
{
	int temp = abs(speed);
	M1.drive(-temp);
	M2.drive(-temp);
}

void backward(Motor M1, Motor M2)
{
	M1.drive(-DEFAULTSPEED);
	M2.drive(-DEFAULTSPEED);
}

void left(Motor left, Motor right, int speed)
{
	int temp = abs(speed)/2;
	left.drive(-temp);
	right.drive(temp);	
}


void right(Motor left, Motor right, int speed)
{
	int temp = abs(speed)/2;
	left.drive(temp);
	right.drive(-temp);	
}

void brake(Motor M1, Motor M2)
{
	M1.brake();
	M2.brake();
}