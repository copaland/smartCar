WiFiCar Motor Driver - TB6612FNG (1A) Arduino Library
=====================================================================

![WiFiCar Motor Driver - TB6612FNG (1A)](https://linkbay.co.kr/tb6612_pcb.jpg)

The TB6612FNG motor driver can control up to two DC motors at a constant current of 1.2A (3.2A peak). 
Two input signals (IN1) can be used to control the motor in one of four function modes - CW, CCW, short-brake, and stop. 
The two motor outputs (A and B) can be separately controlled, the speed of each motor is controlled via a PWM input signal with a frequency up to 100kHz. 
The STBY pin should be pulled high to take the motor out of standby mode.

Repository Contents
-------------------

* **/examples** - Example sketches for the library (.ino). Run these from the Arduino IDE. 
* **/src** - Source files for the library (.cpp, .h).
* **keywords.txt** - Keywords from this library that will be highlighted in the Arduino IDE. 
* **library.properties** - General library properties for the Arduino package manager. 

Documentation
--------------

* **[Installing an Arduino Library Guide](https://github.com/copaland/WiFiCar_TB6612)** - Basic information on how to install an Arduino library.
* **[Product Repository](https://github.com/copaland/WiFiCar_TB6612)** - Main repository for the TB6612FNG Motor Driver.

License Information
-------------------

This product is _**open source**_! 

Please review the LICENSE.md file for license information. 

If you have any questions or concerns on licensing, please contact copaland@naver.com.

Distributed as-is; no warranty is given.

-Your friends at Kimson.


